#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Sep 29 10:59:41 2023

@author: krk
"""

from turtle import Turtle
import pygame

class Scoreboard(Turtle):
    
    def __init__(self):
        super().__init__()
        self.color("white")
        self.penup()
        self.hideturtle()
        self.l_score = 0
        self.r_score = 0
        self.update_scoreboard()

    def update_scoreboard(self):
        self.clear()
        self.goto(-220, 220)
        self.write(self.l_score, align="center", font=("Courier", 30, "bold"))
        self.goto(220, 220)
        self.write(self.r_score, align="center", font=("Courier", 30, "bold"))

    def score_left(self):
        self.l_score += 1
        self.update_scoreboard()
            
    def score_right(self):
        self.r_score += 1
        self.update_scoreboard()

    def gameover(self, winner):
        self.goto(0,0)
        pygame.mixer.init()
        victory_sound = pygame.mixer.Sound("tada_sound.wav")
        victory_sound.play()
        self.write(f"{winner} won the game!", align="center", font=("Courier", 40, "bold"))
        self.screen.ontimer(self.clear, 2500)

    def prompt_restart(self):
        self.goto(0, 0)
        self.write("Press 'r' to restart!", align="center", font=("Courier", 40, "bold"))

    
