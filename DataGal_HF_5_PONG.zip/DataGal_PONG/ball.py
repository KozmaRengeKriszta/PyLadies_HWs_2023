#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Sep 29 10:59:41 2023

@author: krk
"""

from turtle import Turtle
import pygame


class Ball(Turtle):

    def __init__(self, posX, posY):
        super().__init__()
        self.color("white")
        self.shape("circle")
        self.penup()
        self.goto(posX, posY)
        self.velocity = [3, 3]
        pygame.mixer.init()
        self.bounce_sound = pygame.mixer.Sound("owlstorm-bounce.wav")

    def move_ball(self):
        if self.ycor() <-290 or self.ycor() > 290:
            self.velocity[1] *= -1
            self.bounce_sound.play()
        new_x = self.xcor() + self.velocity[0]
        new_y = self.ycor() + self.velocity[1]
        self.goto(new_x, new_y)

    def bounce(self, paddle_y):
        self.velocity[0] *= -1
        self.bounce_sound.play()
        # labda kimozgatása az ütközési zónából, hogy ne tudjon beragadni
        self.goto(self.xcor() + self.velocity[0]*4, self.ycor())
        # labda visszapattanási szögének módosítása
        paddle_height = 100 # hiszen 20*5-re van állítva a paddle hossza
        bounce_multiplier = 4
        collision_point = (self.ycor() - paddle_y) / (paddle_height/2)
        self.velocity[1] = collision_point * bounce_multiplier
