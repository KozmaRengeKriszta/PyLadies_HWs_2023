#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Sep 29 10:59:41 2023

@author: krk
"""

from turtle import Turtle, Screen
from paddle import Paddle
from ball import Ball
from scoreboard import Scoreboard
import pygame
import random


## pálya kirajzolása
main_screen = Screen()
main_screen.title=("Pong")
main_screen.bgcolor("green")
main_screen.setup(800,600, startx=480)


## háló felrajzolása
net_drawer = Turtle()

def draw_net():
    global net_drawer
    net_drawer.hideturtle()  # elrejtem a teknőst, hoyg ne látszódjon, ahogy a pálya aljára megy
    net_drawer.penup()
    net_drawer.goto(0, -290)
    net_drawer.setheading(90)
    net_drawer.color("white")
    net_drawer.pensize(3)

    for i in range(10):
        net_drawer.pendown()
        net_drawer.forward(30)
        net_drawer.penup()
        net_drawer.forward(30)

    net_drawer.hideturtle()

draw_net()


# kikapcsolom a teknős követését a gyorsabb működés érdekében
main_screen.tracer(0)


# ütők példányosítása
l_paddle = Paddle(-340, 0)
r_paddle = Paddle(340, 0)

# ütő események billentyűhöz kapcsolása
main_screen.listen()
main_screen.onkey(l_paddle.move_up, "w")
main_screen.onkey(l_paddle.move_down, "s")
main_screen.onkey(r_paddle.move_up, "Up")
main_screen.onkey(r_paddle.move_down, "Down")


# labda objektum példányosítása 
ball = Ball(0,0)


# kijelző objektum példányosítása
scoreboard = Scoreboard()


game_is_on = False


# 2 mp-es késleltetés után a játék indítása
def start_game():
    global game_is_on
    game_is_on = True
    game_loop()

main_screen.ontimer(start_game, 1500)


# pontszerzés utáni újraindítás
def reset_game():
    ball.velocity = random.choice(([-3, -3], [-3, 3], [3, -3], [3, 3]))
    ball.goto(0, 0)
    l_paddle.goto(-340, 0)
    r_paddle.goto(340, 0)

reset_game()


# új játék indítás felajánlása
def restart_game():
    global game_is_on
    global net_drawer
    
    scoreboard.clear()
    net_drawer.clear()
    
    ball.showturtle()
    ball.goto(0, 0)
    ball.velocity = [3, 3]
    l_paddle.goto(-340, 0)
    r_paddle.goto(340, 0)
    scoreboard.l_score = 0
    scoreboard.r_score = 0
    scoreboard.update_scoreboard() 
    
    main_screen.update()
    draw_net()
    main_screen.ontimer(start_game, 1500)
    
    game_loop()

main_screen.onkey(restart_game, "r")


# főprogram
def game_loop():
    global game_is_on
    ball.move_ball()
    
    # labda visszapattanása az ütőkről (kiegészítés a beragadás ellen: ha megfelelő irányba mozog a labda)
    if ball.xcor() <= -320 and ball.distance(l_paddle) < 60 and ball.velocity[0] < 0:
        ball.bounce(l_paddle.ycor())
    if ball.xcor() >= 320 and ball.distance(r_paddle) < 60 and ball.velocity[0] > 0:
        ball.bounce(r_paddle.ycor())

    # pontszámok változása
    if ball.xcor() <-370:
        goal_sound = pygame.mixer.Sound("goal_sound.wav")
        goal_sound.play()
        scoreboard.score_right()
        reset_game()
    if ball.xcor() > 370:
        goal_sound = pygame.mixer.Sound("goal_sound.wav")
        goal_sound.play()
        scoreboard.score_left()
        reset_game()
        
    # játék vége
    if scoreboard.l_score == 2 or scoreboard.r_score == 2:
        game_is_on = False
        ball.hideturtle()
        net_drawer.clear()
        scoreboard.gameover("LEFT" if scoreboard.l_score == 2 else "RIGHT")
        main_screen.ontimer(scoreboard.prompt_restart, 3000)         

    if game_is_on:
        main_screen.update()
        main_screen.ontimer(game_loop, 10)
    else:
        main_screen.update()
        
game_loop()

    
# ablak bezárása
main_screen.exitonclick()
